package in.Information.Thymleaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThymleafApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThymleafApplication.class, args);
	}

}
